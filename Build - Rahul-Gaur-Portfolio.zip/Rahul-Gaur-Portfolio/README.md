# Rahul Gaur portfolio reproduction

This site preserves the original Framer-generated HTML, CSS, responsive variants,
and compiled animation/component runtime from https://rahulgaur.framer.website/.
It is a source-preserving reproduction, not a newly authored React implementation.
The original compiled modules are retained so motion, layout, and component
interactions do not need to be approximated.

The `dist` directory is the public static site. It includes seven page routes and
local copies of fonts, compiled JavaScript dependencies, and most retrieved images. Large images retain their exact original CDN URLs to fit the publication archive limit without changing image quality.
`source-pages.json` maps the original page URLs to their local copies.
`asset-manifest.json` records the original asset URLs and their local paths.
`retrieval-report.json` records download completeness.

Navigation retains the original routes; social links and the Google Drive resume
link remain external. Placeholder email/telephone targets are corrected to the
contact details visibly printed on the reference. Analytics for the original
Framer site are not included.

Browser inspection was unavailable in this execution environment. Source and
asset validation are recorded separately; no pixel-level visual or interaction
comparison is claimed.

## Scroll repair

All relocated runtime asset references use absolute same-origin URLs. Framer’s responsive-image and image-preload helpers require absolute URLs; root-relative URLs can raise `TypeError: Invalid URL` during rendering. Original component logic, scroll targets, motion curves, breakpoints, and appearance animation payloads are preserved. The floating Framer badge remains hidden. See `scroll-fix-validation.json` for source and resource checks. Browser scroll comparison remains unavailable.

## Case-study navigation repair

Framer CMS is a range-aware binary data service, not a static module asset. The project and blog collection loaders retain their original Framer service base URLs. Relocating those bases to the static mirror made generated `.framercms?range=...` requests fail during client-side page navigation. All four project slug/record mappings and the 20 fields used by each case-study page were loaded successfully through the original runtime; CORS and byte-range behavior were verified. All 116 internal anchor targets resolve. See `case-study-fix-validation.json`.
