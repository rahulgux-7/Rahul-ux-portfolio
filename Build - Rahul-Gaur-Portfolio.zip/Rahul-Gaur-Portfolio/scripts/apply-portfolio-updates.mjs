import fs from 'node:fs';
import path from 'node:path';
import {footerMarkup} from '../dist/portfolio-markup.mjs';
const root = path.resolve(import.meta.dirname, '..');
const dist = path.join(root, 'dist');
const modules = path.join(dist, 'vendor/framerusercontent.com/sites/712eUA2KDfgMy3hRVkj1sj');
const main = path.join(modules, 'script_main.QZxdd8qJ.mjs');
let runtime = fs.readFileSync(main, 'utf8');
if (!runtime.includes('PortfolioFooter')) {
  const target = 'Fn=F(d(function(e,t){';
  if (!runtime.includes(target)) throw Error('Footer component not found');
  runtime = 'import {Footer as PortfolioFooter} from "/portfolio-footer.mjs";\n' + runtime.replace(target, target + 'return m(PortfolioFooter,{});');
  fs.writeFileSync(main, runtime);
}
const homeModule = path.join(modules, 'Yd-yAZDKgordS8S5XUty5J3QvbGO72MUB9qxa7c0sEw.8R1tMqbI.mjs');
fs.writeFileSync(homeModule, fs.readFileSync(homeModule, 'utf8').replace('variant:matchVariant(`SPspkXxBz`)', 'variant:matchVariant(`ljuFfSHo5`)'));
function divEnd(html, start) {
  const tags = /<\/?div\b[^>]*>/g;
  tags.lastIndex = start;
  let depth = 0, tag;
  while ((tag = tags.exec(html))) {
    depth += tag[0].startsWith('</') ? -1 : 1;
    if (!depth) return tags.lastIndex;
  }
  throw Error('Unbalanced services markup');
}
const files = [path.join(dist, 'index.html'), path.join(dist, 'about.html'), path.join(dist, 'projects.html'), ...fs.readdirSync(path.join(dist, 'projects')).filter(f => f.endsWith('.html')).map(f => path.join(dist, 'projects', f))];
for (const file of files) {
  let html = fs.readFileSync(file, 'utf8');
  const pathname = '/' + path.relative(dist, file).replaceAll(path.sep, '/').replace(/index\.html$/, '').replace(/\.html$/, '');
  if (!html.includes('class="rg-footer-area"')) {
    html = html.replace(/<footer\b[^>]*>[\s\S]*?<\/footer>/g, `<div class="rg-footer-area">${footerMarkup(pathname)}</div>`);
    html = html.replace('</head>', '<link rel="stylesheet" href="/portfolio-updates.css"><script defer src="/portfolio-interactions.js"></script></head>');
  }
  // Use the original closed variant in both initial HTML and the live component.
  html = html.replaceAll('framer-1yzos42 framer-v-15na99i" data-framer-name="Desktop / Open - 4"', 'framer-1yzos42 framer-v-1yzos42" data-framer-name="Desktop / Closed"');
  let start = html.indexOf('<div class="framer-rozj1c-container">');
  while (start >= 0) {
    const end = divEnd(html, start);
    let branding = html.slice(start, end);
    const split = branding.indexOf('<div class="framer-of9a55"');
    let top = branding.slice(0, split);
    top = top.replace('framer-v-ooe55w', 'framer-v-1id3mzr').replace('data-framer-name="Desktop / Open"', 'data-framer-name="Desktop / Closed"');
    top = top.replace('--border-color:var(--token-54672876-03f0-4dca-8fdb-32c421a5c4d1, rgb(106, 113, 223))', '--border-color:var(--token-a228d207-519c-4c30-ace3-fe8c17413ec0, rgb(218, 218, 218))');
    top = top.replaceAll('var(--token-54672876-03f0-4dca-8fdb-32c421a5c4d1, rgb(106, 113, 223))', 'var(--token-a9f688eb-778b-4a71-929e-ebf8a014b4cf, rgb(48, 48, 48))');
    top = top.replace('class="framer-i1pcpi-container" style="transform:none"', 'class="framer-i1pcpi-container" style="transform:rotate(180deg)"');
    if (split >= 0 && branding.includes('framer-v-ooe55w')) html = html.slice(0, start) + top + branding.slice(split) + html.slice(end);
    start = html.indexOf('<div class="framer-rozj1c-container">', start + 1);
  }
  fs.writeFileSync(file, html);
}
console.log(`Updated ${files.length} static pages and live footer/services components.`);
